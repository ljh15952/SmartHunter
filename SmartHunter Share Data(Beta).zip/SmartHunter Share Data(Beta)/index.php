<?php
require_once 'Medoo.php';
use Medoo\Medoo;
$data = json_decode(file_get_contents('php://input'), true);

if(isset($data['command']))
{
    $cmd = strtolower($data['command']);
    $db = new Medoo([
            // required
            'database_type' => 'mysql',
            'database_name' => 'smarthunter',
            'server' => '127.0.0.1',
            'username' => 'your db username',
            'password' => 'your db password',
            'charset' => 'utf8_bin',
            'collation' => 'utf_bin',
            'port' => 3306,
    ]);

    $key = $data['key'];
    $host = $data['host'] == 'true' ? true : false;
    if(($key == "" || $key == null) && $cmd != 'alive')
        result(array('status' => 'error', 'result' => 'lobby id cannot be empty', 'data' => $data));
    switch($cmd)
    {
        case 'alive':
            result(array('status' => 'ok', 'result' => 'your ip is : ' . get_client_ip()));
        break;
        case 'hello':
            $count = $db->count("m_data", ["lobbyid" => $key]);
            $dbresult;
            if($count == 0)
            {
                if($host == true)
                    $dbresult = $db->insert("m_data", ["lobbyid" => $key, "hashost" => 1]);
                else
                    $dbresult = $db->insert("m_data", ["lobbyid" => $key, "hasplayer" => 1]);
            }
            else
            {
                if($host == true)
                    $dbresult = $db->update("m_data", ["hashost" => 1], ["lobbyid" => $key]);
                else
                    $dbresult = $db->update("m_data", ["hasplayer" => 1], ["lobbyid" => $key]);
            }
            $affected_rows = $dbresult->rowCount();
            if($affected_rows >= 0)
                result(array('status' => 'ok', 'result' => $key, 'data' => $data));
            result(array('status' => 'error', 'result' => $key, 'data' => $data));
        break;
        case 'check':
            $m_data = $db->get("m_data", "*", ['lobbyid'=>$key]);
            if($m_data != null)
            {
                $hasplayer = $m_data['hasplayer'] ? "true" : "false";
                $hashost = $m_data['hashost'] ? "true" : "false";
                result(array('status' => 'ok', 'result' => array('host' => $hashost, 'players' => $hasplayer), 'data' => $data));
            }
            else
                result(array('status' => 'error', 'result' => 'Empty set', 'data' => $data));
        break;
        case 'push':
            $dbresult = $db->update("m_data", ["data" => $data['data']], ["lobbyid" => $key]);
            $affected_rows = $dbresult->rowCount();
            if($affected_rows == 1)
                result(array('status' => 'ok', 'result' => $key, 'status_$affected_rows' => $affected_rows));
            else
                result(array('status' => 'ok', 'result' => $key, 'status' => 'data no change'));
        break;
        case 'pull':
            $m_data = $db->get("m_data", "*", ['lobbyid'=>$key]);
            if($m_data != null)
                result(array('status' => 'ok', 'result' =>  $m_data['data']));
            else
                result(array('status' => 'error', 'result' =>  'no data'));
        break;
        case 'damage':
            $player = $data['player'];
            $damage = $data['damage'];
            $m_data = $db->get("m_data", "*", ['lobbyid'=>$key]);
            $players = json_decode($m_data['players'], true);
            if($player != null && $damage != null)
            {
                if($players == null)
                    $players = array($player => $damage);
                else
                {
                    $players[$player] = $damage;
                }
                $dbresult = $db->update("m_data", ["players" => json_encode($players)], ["lobbyid" => $key]);
            }
            result(array('status' => 'ok', 'result' =>  $players));
        break;
        case 'done':
            $host = $data['host'] == 'true' ? true : false;
            if($host)
                $dbresult = $db->delete("m_data", ["lobbyid" => $key]);
            else
                $dbresult = $db->delete("m_data", ["lobbyid" => $key, "hashost" => "0", "players" => null]);
            $affected_rows = $dbresult->rowCount();
            $db->delete("m_data", Medoo::raw("WHERE TIMESTAMPDIFF(SECOND, <lastmodify>, NOW()) > 3600"));
            result(array('status' => 'ok', 'result' => $key, 'effectrows' => $affected_rows));
        break;
        default:
            result(array('status' => 'error', 'result'=>$data));
        break;
    }
}
else
{
    result(array('status' => 'error', 'result'=>'no command'));
}


function result($arr)
{
    echo json_encode($arr);
    exit(0);
}

function get_client_ip() {
    $ipaddress = '';
    if (isset($_SERVER['HTTP_CLIENT_IP']))
        $ipaddress = $_SERVER['HTTP_CLIENT_IP'];
    else if(isset($_SERVER['HTTP_X_FORWARDED_FOR']))
        $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
    else if(isset($_SERVER['HTTP_X_FORWARDED']))
        $ipaddress = $_SERVER['HTTP_X_FORWARDED'];
    else if(isset($_SERVER['HTTP_FORWARDED_FOR']))
        $ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
    else if(isset($_SERVER['HTTP_FORWARDED']))
        $ipaddress = $_SERVER['HTTP_FORWARDED'];
    else if(isset($_SERVER['REMOTE_ADDR']))
        $ipaddress = $_SERVER['REMOTE_ADDR'];
    else
        $ipaddress = 'UNKNOWN';
    return $ipaddress;
}
?>
